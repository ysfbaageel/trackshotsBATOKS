import 'shot_model.dart';

/// Mirrors the backend's StatsSummaryResponse.
class StatsSummary {
  final ShotType? shotType; // null = combined across all types
  final int bestScore;
  final double averageScore;
  final int totalShots;

  final double? currentWeekAvg;
  final double? previousWeekAvg;
  final double? weeklyImprovementPct;

  final double? currentMonthAvg;
  final double? previousMonthAvg;
  final double? monthlyImprovementPct;

  const StatsSummary({
    this.shotType,
    required this.bestScore,
    required this.averageScore,
    required this.totalShots,
    this.currentWeekAvg,
    this.previousWeekAvg,
    this.weeklyImprovementPct,
    this.currentMonthAvg,
    this.previousMonthAvg,
    this.monthlyImprovementPct,
  });
}

/// Mirrors the backend's PersonalRecordResponse.
class PersonalRecord {
  final ShotType? shotType; // null = best across all types combined
  final String metricName;
  final String displayLabel;
  final double value;
  final DateTime achievedAt;

  const PersonalRecord({
    this.shotType,
    required this.metricName,
    required this.displayLabel,
    required this.value,
    required this.achievedAt,
  });
}

/// Mirrors the backend's SessionStatsResponse.
class SessionStat {
  final DateTime sessionStart;
  final DateTime sessionEnd;
  final int shotCount;
  final double avgScore;
  final int bestScore;

  const SessionStat({
    required this.sessionStart,
    required this.sessionEnd,
    required this.shotCount,
    required this.avgScore,
    required this.bestScore,
  });
}

class ProgressionPoint {
  final DateTime date;
  final double avgScore;

  const ProgressionPoint({required this.date, required this.avgScore});
}

class MockStatsData {
  MockStatsData._();

  static final StatsSummary summary = StatsSummary(
    bestScore: 96,
    averageScore: 82.4,
    totalShots: 48,
    currentWeekAvg: 85.2,
    previousWeekAvg: 79.8,
    weeklyImprovementPct: 6.8,
    currentMonthAvg: 83.0,
    previousMonthAvg: 78.5,
    monthlyImprovementPct: 5.7,
  );

  static final List<PersonalRecord> personalRecords = [
    PersonalRecord(
      metricName: 'overall_score',
      displayLabel: 'Best Overall Score',
      value: 96,
      achievedAt: DateTime.now().subtract(const Duration(days: 6)),
    ),
    PersonalRecord(
      shotType: ShotType.power,
      metricName: 'power',
      displayLabel: 'Best Power Score',
      value: 94,
      achievedAt: DateTime.now().subtract(const Duration(days: 6)),
    ),
    PersonalRecord(
      shotType: ShotType.curve,
      metricName: 'curve',
      displayLabel: 'Best Curve Score',
      value: 91,
      achievedAt: DateTime.now().subtract(const Duration(days: 14)),
    ),
    PersonalRecord(
      shotType: ShotType.knuckleball,
      metricName: 'knuckleball',
      displayLabel: 'Best Knuckleball Score',
      value: 78,
      achievedAt: DateTime.now().subtract(const Duration(days: 21)),
    ),
    PersonalRecord(
      shotType: ShotType.lowDriven,
      metricName: 'low_driven',
      displayLabel: 'Best Low Driven Score',
      value: 85,
      achievedAt: DateTime.now().subtract(const Duration(days: 3)),
    ),
    PersonalRecord(
      metricName: 'control',
      displayLabel: 'Best Control Score',
      value: 93,
      achievedAt: DateTime.now().subtract(const Duration(days: 9)),
    ),
  ];

  static final List<SessionStat> sessions = [
    SessionStat(
      sessionStart: DateTime.now().subtract(const Duration(hours: 3)),
      sessionEnd: DateTime.now().subtract(const Duration(hours: 2, minutes: 20)),
      shotCount: 6,
      avgScore: 85.2,
      bestScore: 94,
    ),
    SessionStat(
      sessionStart: DateTime.now().subtract(const Duration(days: 1, hours: 5)),
      sessionEnd: DateTime.now().subtract(const Duration(days: 1, hours: 4, minutes: 30)),
      shotCount: 4,
      avgScore: 78.5,
      bestScore: 88,
    ),
    SessionStat(
      sessionStart: DateTime.now().subtract(const Duration(days: 3, hours: 8)),
      sessionEnd: DateTime.now().subtract(const Duration(days: 3, hours: 7)),
      shotCount: 8,
      avgScore: 81.0,
      bestScore: 96,
    ),
    SessionStat(
      sessionStart: DateTime.now().subtract(const Duration(days: 6, hours: 2)),
      sessionEnd: DateTime.now().subtract(const Duration(days: 6, hours: 1, minutes: 15)),
      shotCount: 5,
      avgScore: 76.4,
      bestScore: 89,
    ),
  ];

  /// 30 days of daily-bucketed average score, matching the shape of
  /// the backend's /users/me/progression endpoint.
  static List<ProgressionPoint> get progression {
    final points = <ProgressionPoint>[];
    final base = 68.0;
    for (int i = 29; i >= 0; i--) {
      final trend = (29 - i) * 0.55; // gentle upward trend
      final noise = ((i * 37) % 11) - 5; // deterministic pseudo-noise
      final score = (base + trend + noise).clamp(45.0, 98.0);
      points.add(ProgressionPoint(date: DateTime.now().subtract(Duration(days: i)), avgScore: score));
    }
    return points;
  }
}
