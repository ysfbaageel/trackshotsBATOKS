/// Enum mirroring the backend's shot_type. Kept as a simple enum here since
/// this is the presentation layer; the data layer would map this to/from
/// the API's string representation.
enum ShotType { curve, knuckleball, lowDriven, power }

extension ShotTypeX on ShotType {
  String get label {
    switch (this) {
      case ShotType.curve:
        return 'Curve';
      case ShotType.knuckleball:
        return 'Knuckleball';
      case ShotType.lowDriven:
        return 'Low Driven';
      case ShotType.power:
        return 'Power';
    }
  }

  String get apiValue {
    switch (this) {
      case ShotType.curve:
        return 'curve';
      case ShotType.knuckleball:
        return 'knuckleball';
      case ShotType.lowDriven:
        return 'low_driven';
      case ShotType.power:
        return 'power';
    }
  }
}

enum ShotJobStatus { queued, processing, completed, failed }

/// A single scored metric shown on the results breakdown (e.g. "Spin Rate").
class ShotMetric {
  final String label;
  final double value; // 0-100 normalized
  final String rawDisplay; // e.g. "18.4 rad/s"

  const ShotMetric({required this.label, required this.value, required this.rawDisplay});
}

/// Mock shot result — mirrors the `shot_results` backend table shape.
class ShotResult {
  final String id;
  final ShotType shotType;
  final int overallScore;
  final DateTime createdAt;
  final String thumbnailAsset;
  final List<ShotMetric> metrics;
  final String feedback;
  final double confidence; // 0-1, model confidence

  const ShotResult({
    required this.id,
    required this.shotType,
    required this.overallScore,
    required this.createdAt,
    required this.thumbnailAsset,
    required this.metrics,
    required this.feedback,
    required this.confidence,
  });
}

/// Static mock dataset so every screen renders realistic UI without a backend.
class MockData {
  MockData._();

  static final List<ShotResult> shotHistory = [
    ShotResult(
      id: 'shot_1',
      shotType: ShotType.curve,
      overallScore: 87,
      createdAt: DateTime.now().subtract(const Duration(hours: 3)),
      thumbnailAsset: 'assets/images/pitch_placeholder.jpg',
      confidence: 0.81,
      feedback:
          'Strong curvature with consistent arc. Try increasing hip rotation slightly for more spin.',
      metrics: const [
        ShotMetric(label: 'Curvature', value: 91, rawDisplay: '0.62 rad'),
        ShotMetric(label: 'Spin Rate', value: 84, rawDisplay: '9.2 rev/s'),
        ShotMetric(label: 'Contact Angle', value: 78, rawDisplay: '23°'),
        ShotMetric(label: 'Consistency', value: 88, rawDisplay: 'High'),
      ],
    ),
    ShotResult(
      id: 'shot_2',
      shotType: ShotType.power,
      overallScore: 92,
      createdAt: DateTime.now().subtract(const Duration(days: 1, hours: 2)),
      thumbnailAsset: 'assets/images/pitch_placeholder.jpg',
      confidence: 0.9,
      feedback: 'Excellent swing speed and clean contact. Among your best power shots yet.',
      metrics: const [
        ShotMetric(label: 'Ball Speed', value: 95, rawDisplay: '108 km/h'),
        ShotMetric(label: 'Swing Speed', value: 90, rawDisplay: '21 m/s'),
        ShotMetric(label: 'Energy Transfer', value: 89, rawDisplay: '86%'),
        ShotMetric(label: 'Contact Quality', value: 93, rawDisplay: 'Clean'),
      ],
    ),
    ShotResult(
      id: 'shot_3',
      shotType: ShotType.knuckleball,
      overallScore: 74,
      createdAt: DateTime.now().subtract(const Duration(days: 2, hours: 5)),
      thumbnailAsset: 'assets/images/pitch_placeholder.jpg',
      confidence: 0.68,
      feedback: 'Good spin suppression. Trajectory unpredictability could be higher for max effect.',
      metrics: const [
        ShotMetric(label: 'Spin Suppression', value: 80, rawDisplay: '1.1 rev/s'),
        ShotMetric(label: 'Unpredictability', value: 66, rawDisplay: 'Moderate'),
        ShotMetric(label: 'Contact Point', value: 75, rawDisplay: 'Center-dead'),
        ShotMetric(label: 'Consistency', value: 71, rawDisplay: 'Moderate'),
      ],
    ),
    ShotResult(
      id: 'shot_4',
      shotType: ShotType.lowDriven,
      overallScore: 81,
      createdAt: DateTime.now().subtract(const Duration(days: 4)),
      thumbnailAsset: 'assets/images/pitch_placeholder.jpg',
      confidence: 0.85,
      feedback: 'Flat, driven trajectory with good velocity. Slightly high at the 6-yard mark.',
      metrics: const [
        ShotMetric(label: 'Max Height', value: 74, rawDisplay: '0.9 m'),
        ShotMetric(label: 'Velocity', value: 88, rawDisplay: '96 km/h'),
        ShotMetric(label: 'Flatness', value: 80, rawDisplay: 'High'),
        ShotMetric(label: 'Accuracy', value: 82, rawDisplay: 'On target'),
      ],
    ),
  ];

  static List<ShotResult> get recent => shotHistory;
}

class LeaderboardEntry {
  final String rank;
  final String name;
  final String avatarInitial;
  final int score;
  final ShotType topShotType;
  final bool isCurrentUser;

  const LeaderboardEntry({
    required this.rank,
    required this.name,
    required this.avatarInitial,
    required this.score,
    required this.topShotType,
    this.isCurrentUser = false,
  });
}

final List<LeaderboardEntry> mockLeaderboard = [
  const LeaderboardEntry(rank: '1', name: 'Marcus Reyes', avatarInitial: 'M', score: 96, topShotType: ShotType.power),
  const LeaderboardEntry(rank: '2', name: 'Aiko Tanaka', avatarInitial: 'A', score: 94, topShotType: ShotType.curve),
  const LeaderboardEntry(rank: '3', name: 'Diego Fernandez', avatarInitial: 'D', score: 93, topShotType: ShotType.curve),
  const LeaderboardEntry(rank: '4', name: 'You', avatarInitial: 'Y', score: 89, topShotType: ShotType.power, isCurrentUser: true),
  const LeaderboardEntry(rank: '5', name: 'Sofia Marchetti', avatarInitial: 'S', score: 88, topShotType: ShotType.lowDriven),
  const LeaderboardEntry(rank: '6', name: 'Liam O\'Connor', avatarInitial: 'L', score: 85, topShotType: ShotType.knuckleball),
  const LeaderboardEntry(rank: '7', name: 'Priya Nair', avatarInitial: 'P', score: 83, topShotType: ShotType.curve),
];
