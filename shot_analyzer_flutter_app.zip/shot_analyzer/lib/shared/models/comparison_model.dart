import 'shot_model.dart';

class TrajectoryPoint3 {
  final double timestampSec;
  final double xM;
  final double heightM;

  const TrajectoryPoint3({required this.timestampSec, required this.xM, required this.heightM});
}

/// Mirrors the backend's ReferenceShotSummary.
class ReferenceShot {
  final String id;
  final String displayName;
  final String playerStyle;
  final ShotType shotType;
  final String description;
  final bool isIllustrative;

  const ReferenceShot({
    required this.id,
    required this.displayName,
    required this.playerStyle,
    required this.shotType,
    required this.description,
    this.isIllustrative = true,
  });
}

/// Mirrors the backend's ShotSideSummary.
class ComparisonSide {
  final String label;
  final ShotType shotType;
  final double ballSpeedKmh;
  final double launchAngleDeg;
  final double horizontalCurveM;
  final double powerScore;
  final double? overallScore;
  final List<TrajectoryPoint3> trajectory;
  final bool isIllustrative;

  const ComparisonSide({
    required this.label,
    required this.shotType,
    required this.ballSpeedKmh,
    required this.launchAngleDeg,
    required this.horizontalCurveM,
    required this.powerScore,
    this.overallScore,
    required this.trajectory,
    this.isIllustrative = false,
  });
}

/// Mirrors the backend's DimensionComparison.
class DimensionComparison {
  final String dimension; // "trajectory" | "speed" | "curve" | "launch_angle" | "power"
  final double yourValue;
  final double targetValue;
  final String unit;
  final double similarityPct;

  const DimensionComparison({
    required this.dimension,
    required this.yourValue,
    required this.targetValue,
    required this.unit,
    required this.similarityPct,
  });

  String get label {
    switch (dimension) {
      case 'trajectory':
        return 'Trajectory Shape';
      case 'speed':
        return 'Speed';
      case 'curve':
        return 'Curve';
      case 'launch_angle':
        return 'Launch Angle';
      case 'power':
        return 'Power';
      default:
        return dimension;
    }
  }
}

/// Mirrors the backend's ComparisonResult.
class ComparisonResult {
  final ComparisonSide yourShot;
  final ComparisonSide target;
  final List<DimensionComparison> dimensions;
  final double overallSimilarityPct;
  final String summary;

  const ComparisonResult({
    required this.yourShot,
    required this.target,
    required this.dimensions,
    required this.overallSimilarityPct,
    required this.summary,
  });
}

List<TrajectoryPoint3> _mockParabola({required double peak, required double duration, int n = 24}) {
  return List.generate(n, (i) {
    final t = duration * i / (n - 1);
    final h = (peak * (1 - ((t - duration / 2) / (duration / 2)) * ((t - duration / 2) / (duration / 2))))
        .clamp(0.0, double.infinity);
    return TrajectoryPoint3(timestampSec: t, xM: t * 15, heightM: h);
  });
}

class MockComparisonData {
  MockComparisonData._();

  static final List<ReferenceShot> referenceShots = [
    const ReferenceShot(
      id: 'ref_ronaldo',
      displayName: 'Knuckleball Reference (Ronaldo-style)',
      playerStyle: 'Ronaldo-style',
      shotType: ShotType.knuckleball,
      description:
          'An illustrative profile representing the low-spin, unpredictable-flight knuckleball technique '
          'associated with Cristiano Ronaldo\'s free-kick style — based on the well-documented characteristics '
          'of this technique, not a measurement of a specific recorded shot.',
    ),
    const ReferenceShot(
      id: 'ref_messi',
      displayName: 'Curve Reference (Messi-style)',
      playerStyle: 'Messi-style',
      shotType: ShotType.curve,
      description:
          'An illustrative profile representing a heavily-curled, moderate-pace free kick in the style widely '
          'associated with Lionel Messi. Not a measurement of a specific recorded shot.',
    ),
    const ReferenceShot(
      id: 'ref_carlos',
      displayName: 'Curve + Power Reference (Roberto Carlos-style)',
      playerStyle: 'Roberto Carlos-style',
      shotType: ShotType.curve,
      description:
          'An illustrative profile inspired by the combination of extreme curve and high power long associated '
          'with Roberto Carlos\'s free-kick technique. Not a measurement of any specific recorded shot.',
    ),
    const ReferenceShot(
      id: 'ref_debruyne',
      displayName: 'Driven Shot Reference (De Bruyne-style)',
      playerStyle: 'De Bruyne-style',
      shotType: ShotType.lowDriven,
      description:
          'An illustrative profile representing a flat, powerfully-struck driven shot in the style widely '
          'associated with Kevin De Bruyne. Not a measurement of a specific recorded shot.',
    ),
    const ReferenceShot(
      id: 'ref_power',
      displayName: 'Power Reference (Professional Average)',
      playerStyle: 'Professional Average',
      shotType: ShotType.power,
      description:
          'An illustrative profile representing a strong, well-struck power shot at the upper end of the '
          'realistic professional speed range — a general benchmark, not an individual player\'s shot.',
    ),
  ];

  /// Builds a mock comparison result for the given user shot + reference id,
  /// standing in for a real `GET /shots/{id}/compare` call.
  static ComparisonResult compare({required ShotType yourShotType, required String referenceId}) {
    final ref = referenceShots.firstWhere((r) => r.id == referenceId);

    final yourSide = ComparisonSide(
      label: 'Your Shot',
      shotType: yourShotType,
      ballSpeedKmh: 88,
      launchAngleDeg: 12,
      horizontalCurveM: 1.4,
      powerScore: 62,
      overallScore: 81,
      trajectory: _mockParabola(peak: 1.6, duration: 0.8),
    );

    final refSpeeds = {
      'ref_ronaldo': 97.0, 'ref_messi': 76.0, 'ref_carlos': 113.0, 'ref_debruyne': 104.0, 'ref_power': 121.0,
    };
    final refAngles = {
      'ref_ronaldo': 9.0, 'ref_messi': 13.0, 'ref_carlos': 10.0, 'ref_debruyne': 4.0, 'ref_power': 11.0,
    };
    final refCurves = {
      'ref_ronaldo': 0.3, 'ref_messi': 2.6, 'ref_carlos': 3.7, 'ref_debruyne': 0.4, 'ref_power': 0.3,
    };
    final refPower = {
      'ref_ronaldo': 74.0, 'ref_messi': 54.0, 'ref_carlos': 89.0, 'ref_debruyne': 81.0, 'ref_power': 96.0,
    };
    final refPeakHeight = {
      'ref_ronaldo': 0.9, 'ref_messi': 1.15, 'ref_carlos': 1.51, 'ref_debruyne': 0.21, 'ref_power': 2.1,
    };
    final refDuration = {
      'ref_ronaldo': 0.75, 'ref_messi': 0.9, 'ref_carlos': 0.85, 'ref_debruyne': 0.65, 'ref_power': 0.8,
    };

    final targetSide = ComparisonSide(
      label: ref.displayName,
      shotType: ref.shotType,
      ballSpeedKmh: refSpeeds[referenceId]!,
      launchAngleDeg: refAngles[referenceId]!,
      horizontalCurveM: refCurves[referenceId]!,
      powerScore: refPower[referenceId]!,
      overallScore: null,
      trajectory: _mockParabola(peak: refPeakHeight[referenceId]!, duration: refDuration[referenceId]!),
      isIllustrative: true,
    );

    double scalarSim(double a, double b, double tolerance) {
      final diff = (a - b).abs();
      return (100 * (1 - diff / tolerance)).clamp(0.0, 100.0);
    }

    final dims = [
      DimensionComparison(
        dimension: 'trajectory', yourValue: 0, targetValue: 0, unit: 'shape',
        similarityPct: 68 + (referenceId == 'ref_messi' ? 15 : 0),
      ),
      DimensionComparison(
        dimension: 'speed', yourValue: yourSide.ballSpeedKmh, targetValue: targetSide.ballSpeedKmh, unit: 'km/h',
        similarityPct: scalarSim(yourSide.ballSpeedKmh, targetSide.ballSpeedKmh, 40),
      ),
      DimensionComparison(
        dimension: 'curve', yourValue: yourSide.horizontalCurveM, targetValue: targetSide.horizontalCurveM, unit: 'm',
        similarityPct: scalarSim(yourSide.horizontalCurveM, targetSide.horizontalCurveM, 3.0),
      ),
      DimensionComparison(
        dimension: 'launch_angle', yourValue: yourSide.launchAngleDeg, targetValue: targetSide.launchAngleDeg,
        unit: 'deg', similarityPct: scalarSim(yourSide.launchAngleDeg, targetSide.launchAngleDeg, 20),
      ),
      DimensionComparison(
        dimension: 'power', yourValue: yourSide.powerScore, targetValue: targetSide.powerScore, unit: 'score',
        similarityPct: scalarSim(yourSide.powerScore, targetSide.powerScore, 50),
      ),
    ];

    final weights = {'trajectory': 0.30, 'speed': 0.25, 'curve': 0.20, 'launch_angle': 0.15, 'power': 0.10};
    final overall = dims.fold<double>(0, (sum, d) => sum + d.similarityPct * (weights[d.dimension] ?? 0));

    String tone;
    if (overall >= 85) {
      tone = 'remarkably close to';
    } else if (overall >= 65) {
      tone = 'fairly similar to';
    } else if (overall >= 40) {
      tone = 'somewhat different from';
    } else {
      tone = 'quite different from';
    }

    return ComparisonResult(
      yourShot: yourSide,
      target: targetSide,
      dimensions: dims,
      overallSimilarityPct: overall,
      summary: 'Your shot is $tone ${targetSide.label} — ${overall.toStringAsFixed(0)}% overall similarity.',
    );
  }

  /// Builds a mock comparison between two of the user's own analyzed shots
  /// (including gallery uploads, which go through the same pipeline).
  /// Since the app-wide `ShotResult` mock model only carries generic
  /// display metrics (not raw physics doubles), this derives illustrative
  /// but deterministic physics values from each shot's existing data
  /// (shot type + overall score) rather than introducing random mock
  /// numbers that would change on every rebuild.
  static ComparisonResult compareShots(ShotResult yourShot, ShotResult otherShot) {
    ComparisonSide sideFrom(ShotResult shot, String label) {
      final scoreFactor = shot.overallScore / 100.0;
      final baseSpeed = {
        ShotType.power: 90.0, ShotType.lowDriven: 85.0, ShotType.curve: 65.0, ShotType.knuckleball: 70.0,
      }[shot.shotType]!;
      final baseCurve = {
        ShotType.power: 0.4, ShotType.lowDriven: 0.3, ShotType.curve: 1.5, ShotType.knuckleball: 0.5,
      }[shot.shotType]!;
      final baseAngle = {
        ShotType.power: 11.0, ShotType.lowDriven: 4.0, ShotType.curve: 13.0, ShotType.knuckleball: 9.0,
      }[shot.shotType]!;
      final basePeak = {
        ShotType.power: 1.7, ShotType.lowDriven: 0.5, ShotType.curve: 1.6, ShotType.knuckleball: 1.2,
      }[shot.shotType]!;

      return ComparisonSide(
        label: label,
        shotType: shot.shotType,
        ballSpeedKmh: baseSpeed * (0.75 + 0.3 * scoreFactor),
        launchAngleDeg: baseAngle,
        horizontalCurveM: baseCurve * (0.7 + 0.5 * scoreFactor),
        powerScore: 40 + 55 * scoreFactor,
        overallScore: shot.overallScore.toDouble(),
        trajectory: _mockParabola(peak: basePeak * (0.8 + 0.3 * scoreFactor), duration: 0.8),
      );
    }

    final yourSide = sideFrom(yourShot, 'Your Shot');
    final targetSide = sideFrom(otherShot, 'Comparison Shot');

    double scalarSim(double a, double b, double tolerance) {
      final diff = (a - b).abs();
      return (100 * (1 - diff / tolerance)).clamp(0.0, 100.0);
    }

    final dims2 = [
      DimensionComparison(
        dimension: 'trajectory', yourValue: 0, targetValue: 0, unit: 'shape',
        similarityPct: yourShot.shotType == otherShot.shotType ? 82 : 55,
      ),
      DimensionComparison(
        dimension: 'speed', yourValue: yourSide.ballSpeedKmh, targetValue: targetSide.ballSpeedKmh, unit: 'km/h',
        similarityPct: scalarSim(yourSide.ballSpeedKmh, targetSide.ballSpeedKmh, 40),
      ),
      DimensionComparison(
        dimension: 'curve', yourValue: yourSide.horizontalCurveM, targetValue: targetSide.horizontalCurveM, unit: 'm',
        similarityPct: scalarSim(yourSide.horizontalCurveM, targetSide.horizontalCurveM, 3.0),
      ),
      DimensionComparison(
        dimension: 'launch_angle', yourValue: yourSide.launchAngleDeg, targetValue: targetSide.launchAngleDeg,
        unit: 'deg', similarityPct: scalarSim(yourSide.launchAngleDeg, targetSide.launchAngleDeg, 20),
      ),
      DimensionComparison(
        dimension: 'power', yourValue: yourSide.powerScore, targetValue: targetSide.powerScore, unit: 'score',
        similarityPct: scalarSim(yourSide.powerScore, targetSide.powerScore, 50),
      ),
    ];

    final weights2 = {'trajectory': 0.30, 'speed': 0.25, 'curve': 0.20, 'launch_angle': 0.15, 'power': 0.10};
    final overall2 = dims2.fold<double>(0, (sum, d) => sum + d.similarityPct * (weights2[d.dimension] ?? 0));

    String tone2;
    if (overall2 >= 85) {
      tone2 = 'remarkably close to';
    } else if (overall2 >= 65) {
      tone2 = 'fairly similar to';
    } else if (overall2 >= 40) {
      tone2 = 'somewhat different from';
    } else {
      tone2 = 'quite different from';
    }

    return ComparisonResult(
      yourShot: yourSide,
      target: targetSide,
      dimensions: dims2,
      overallSimilarityPct: overall2,
      summary: 'Your shot is $tone2 your comparison shot — ${overall2.toStringAsFixed(0)}% overall similarity.',
    );
  }
}
