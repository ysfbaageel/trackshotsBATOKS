import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../config/app_config.dart';
import 'api_exception.dart';

/// Central HTTP client for every real backend call in the app. Attaches
/// the current Firebase ID token to every request (matching the backend's
/// `get_current_user` dependency, which expects a Bearer token) and maps
/// every failure onto [ApiException] so calling code never has to deal
/// with raw Dio exceptions or parse the backend's error envelope itself.
///
/// Firebase ID tokens expire in ~1 hour; `getIdToken()` (without `true`)
/// returns a cached token and only triggers a network refresh when it's
/// actually near expiry, so calling it on every request is cheap in the
/// common case.
class ApiClient {
  late final Dio _dio;

  ApiClient() {
    _dio = Dio(BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 30),
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          final token = await user.getIdToken();
          options.headers['Authorization'] = 'Bearer $token';
        }
        handler.next(options);
      },
      onError: (DioException error, handler) {
        handler.next(error);
      },
    ));
  }

  Future<Map<String, dynamic>> get(String path, {Map<String, dynamic>? queryParameters}) async {
    return _unwrap(() => _dio.get(path, queryParameters: queryParameters));
  }

  Future<Map<String, dynamic>> post(String path, {Map<String, dynamic>? data}) async {
    return _unwrap(() => _dio.post(path, data: data));
  }

  Future<List<dynamic>> getList(String path, {Map<String, dynamic>? queryParameters}) async {
    final response = await _unwrapRaw(() => _dio.get(path, queryParameters: queryParameters));
    return response.data as List<dynamic>;
  }

  Future<void> delete(String path) async {
    await _unwrapRaw(() => _dio.delete(path));
  }

  Future<Map<String, dynamic>> _unwrap(Future<Response> Function() request) async {
    final response = await _unwrapRaw(request);
    return response.data as Map<String, dynamic>;
  }

  Future<Response> _unwrapRaw(Future<Response> Function() request) async {
    try {
      return await request();
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  ApiException _mapError(DioException e) {
    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.connectionError) {
      return ApiException.network('Could not reach the server. Check your connection and try again.');
    }

    final data = e.response?.data;
    if (data is Map<String, dynamic> && data.containsKey('error_code')) {
      return ApiException(
        errorCode: data['error_code'] as String,
        message: data['message'] as String? ?? 'Something went wrong.',
        statusCode: e.response?.statusCode,
      );
    }

    return ApiException.unknown(e.message ?? 'An unexpected error occurred.');
  }
}
