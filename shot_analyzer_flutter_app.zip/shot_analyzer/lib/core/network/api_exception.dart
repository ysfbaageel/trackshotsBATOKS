/// Mirrors the backend's `{error_code, message}` error envelope (see
/// `app/main.py`'s exception handlers in the backend project) so callers
/// can branch on stable error codes rather than parsing message strings.
class ApiException implements Exception {
  final String errorCode;
  final String message;
  final int? statusCode;

  const ApiException({required this.errorCode, required this.message, this.statusCode});

  factory ApiException.network(String message) =>
      ApiException(errorCode: 'network_error', message: message);

  factory ApiException.unknown(String message) =>
      ApiException(errorCode: 'unknown_error', message: message);

  bool get isAuthError => errorCode == 'unauthorized' || errorCode == 'token_expired' || errorCode == 'invalid_token';
  bool get isNotFound => errorCode == 'not_found';
  bool get isRateLimited => errorCode == 'rate_limit_exceeded';

  @override
  String toString() => 'ApiException($errorCode: $message)';
}
