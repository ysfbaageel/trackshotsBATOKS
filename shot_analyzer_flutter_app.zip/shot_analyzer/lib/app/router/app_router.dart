import 'package:go_router/go_router.dart';

import '../../features/splash/presentation/screens/splash_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/home/presentation/screens/home_shell_screen.dart';
import '../../features/shot_capture/presentation/screens/record_video_screen.dart';
import '../../features/shot_capture/presentation/screens/upload_video_screen.dart';
import '../../features/shot_capture/presentation/screens/video_preview_screen.dart';
import '../../features/shot_analysis/presentation/screens/processing_screen.dart';
import '../../features/shot_analysis/presentation/screens/results_screen.dart';
import '../../features/stats/presentation/screens/statistics_screen.dart';
import '../../features/comparison/presentation/screens/comparison_picker_screen.dart';
import '../../features/comparison/presentation/screens/comparison_result_screen.dart';
import '../../shared/models/shot_model.dart';

class AppRoutes {
  AppRoutes._();
  static const splash = '/';
  static const login = '/login';
  static const register = '/register';
  static const home = '/home';
  static const record = '/record';
  static const upload = '/upload';
  static const preview = '/preview';
  static const processing = '/processing';
  static const results = '/results';
  static const statistics = '/statistics';
  static const comparisonPicker = '/compare';
  static const comparisonResult = '/compare/result';
}

final GoRouter appRouter = GoRouter(
  initialLocation: AppRoutes.splash,
  routes: [
    GoRoute(
      path: AppRoutes.splash,
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: AppRoutes.login,
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: AppRoutes.register,
      builder: (context, state) => const RegisterScreen(),
    ),
    GoRoute(
      path: AppRoutes.home,
      builder: (context, state) => const HomeShellScreen(),
    ),
    GoRoute(
      path: AppRoutes.record,
      builder: (context, state) => const RecordVideoScreen(),
    ),
    GoRoute(
      path: AppRoutes.upload,
      builder: (context, state) => const UploadVideoScreen(),
    ),
    GoRoute(
      path: AppRoutes.preview,
      builder: (context, state) {
        final videoPath = state.extra as String?;
        return VideoPreviewScreen(videoPath: videoPath ?? '');
      },
    ),
    GoRoute(
      path: AppRoutes.processing,
      builder: (context, state) {
        final shotType = state.extra as ShotType? ?? ShotType.power;
        return ProcessingScreen(shotType: shotType);
      },
    ),
    GoRoute(
      path: AppRoutes.results,
      builder: (context, state) {
        final result = state.extra as ShotResult?;
        return ResultsScreen(result: result ?? MockData.shotHistory.first);
      },
    ),
    GoRoute(
      path: AppRoutes.statistics,
      builder: (context, state) => const StatisticsScreen(),
    ),
    GoRoute(
      path: AppRoutes.comparisonPicker,
      builder: (context, state) {
        final yourShot = state.extra as ShotResult? ?? MockData.shotHistory.first;
        return ComparisonPickerScreen(yourShot: yourShot);
      },
    ),
    GoRoute(
      path: AppRoutes.comparisonResult,
      builder: (context, state) {
        final args = state.extra as ComparisonNavArgs;
        return ComparisonResultScreen(args: args);
      },
    ),
  ],
);
