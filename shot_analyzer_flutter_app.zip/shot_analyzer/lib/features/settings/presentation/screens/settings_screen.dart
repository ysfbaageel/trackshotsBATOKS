import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/router/app_router.dart';
import '../../../../shared/widgets/common_widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _pushNotifications = true;
  bool _emailUpdates = false;
  bool _trainingConsent = true;
  bool _highQualityUpload = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Settings'),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => Navigator.of(context).pop()),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
          children: [
            const _SettingsGroupLabel('Account'),
            AppCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  _NavRow(icon: Icons.person_outline_rounded, label: 'Edit Profile', onTap: () {}),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _NavRow(icon: Icons.lock_outline_rounded, label: 'Change Password', onTap: () {}),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _NavRow(icon: Icons.workspace_premium_outlined, label: 'Subscription · Free Plan', onTap: () {}),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const _SettingsGroupLabel('Notifications'),
            AppCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  _SwitchRow(
                    icon: Icons.notifications_none_rounded,
                    label: 'Push notifications',
                    subtitle: 'Get notified when analysis completes',
                    value: _pushNotifications,
                    onChanged: (v) => setState(() => _pushNotifications = v),
                  ),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _SwitchRow(
                    icon: Icons.mail_outline_rounded,
                    label: 'Email updates',
                    subtitle: 'Weekly performance summaries',
                    value: _emailUpdates,
                    onChanged: (v) => setState(() => _emailUpdates = v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const _SettingsGroupLabel('Video & Data'),
            AppCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  _SwitchRow(
                    icon: Icons.high_quality_outlined,
                    label: 'High-quality uploads',
                    subtitle: 'Uses more data, improves accuracy',
                    value: _highQualityUpload,
                    onChanged: (v) => setState(() => _highQualityUpload = v),
                  ),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _SwitchRow(
                    icon: Icons.model_training_rounded,
                    label: 'Help improve the model',
                    subtitle: 'Share your shots (anonymized) to train future models',
                    value: _trainingConsent,
                    onChanged: (v) => setState(() => _trainingConsent = v),
                  ),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _NavRow(icon: Icons.delete_outline_rounded, label: 'Clear local cache', onTap: () {}),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const _SettingsGroupLabel('About'),
            AppCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  _NavRow(icon: Icons.description_outlined, label: 'Terms of Service', onTap: () {}),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _NavRow(icon: Icons.privacy_tip_outlined, label: 'Privacy Policy', onTap: () {}),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _NavRow(icon: Icons.info_outline_rounded, label: 'App version', trailing: 'v1.0.0', onTap: null),
                ],
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => context.go(AppRoutes.login),
                icon: const Icon(Icons.logout_rounded, size: 18, color: AppColors.error),
                label: const Text('Log Out', style: TextStyle(color: AppColors.error)),
                style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.error)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingsGroupLabel extends StatelessWidget {
  final String text;
  const _SettingsGroupLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 4),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(color: AppColors.textMuted, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.6),
      ),
    );
  }
}

class _NavRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? trailing;
  final VoidCallback? onTap;

  const _NavRow({required this.icon, required this.label, this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.textSecondary, size: 22),
      title: Text(label, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
      trailing: trailing != null
          ? Text(trailing!, style: TextStyle(color: AppColors.textMuted, fontSize: 13))
          : (onTap != null ? const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted) : null),
      onTap: onTap,
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchRow({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.textSecondary, size: 22),
      title: Text(label, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle, style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
      trailing: Switch(value: value, onChanged: onChanged, activeColor: AppColors.primary),
    );
  }
}
