import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/router/app_router.dart';
import '../../../../shared/models/shot_model.dart';

/// Guided recording screen. In production this hosts a `CameraController`
/// preview; here the preview area is a styled placeholder so the UI/UX
/// (framing guide, shot-type selector, record controls) can be reviewed
/// independent of camera plugin wiring.
class RecordVideoScreen extends StatefulWidget {
  const RecordVideoScreen({super.key});

  @override
  State<RecordVideoScreen> createState() => _RecordVideoScreenState();
}

class _RecordVideoScreenState extends State<RecordVideoScreen> with SingleTickerProviderStateMixin {
  ShotType _selectedType = ShotType.power;
  bool _isRecording = false;
  int _seconds = 0;
  late final AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _toggleRecording() {
    setState(() => _isRecording = !_isRecording);
    if (_isRecording) {
      _tick();
    } else {
      _seconds = 0;
      // Simulated capture complete -> go to preview with a mock file path.
      context.push(AppRoutes.preview, extra: 'mock_recorded_clip.mp4');
    }
  }

  void _tick() async {
    while (_isRecording && mounted && _seconds < 6) {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted || !_isRecording) return;
      setState(() => _seconds++);
      if (_seconds >= 6) _toggleRecording();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Simulated camera preview background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1A2A1F), Color(0xFF0B0E14)],
              ),
            ),
          ),
          CustomPaint(size: Size.infinite, painter: _FramingGuidePainter()),

          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _circleIconButton(Icons.close_rounded, () => context.pop()),
                      if (_isRecording)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(100),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.fiber_manual_record, color: AppColors.error, size: 14),
                              const SizedBox(width: 6),
                              Text('0:0${_seconds}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      _circleIconButton(Icons.flash_off_rounded, () {}),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.45),
                      borderRadius: BorderRadius.circular(100),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 15),
                        SizedBox(width: 6),
                        Text(
                          'Position camera side-on, full body in frame',
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                ),

                const Spacer(),

                // Shot type selector
                SizedBox(
                  height: 44,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: ShotType.values.map((type) {
                      final selected = _selectedType == type;
                      return Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: ChoiceChip(
                          label: Text(type.label),
                          selected: selected,
                          onSelected: (_) => setState(() => _selectedType = type),
                          backgroundColor: Colors.black.withOpacity(0.4),
                          selectedColor: AppColors.forShotType(type.label).withOpacity(0.25),
                          labelStyle: TextStyle(
                            color: selected ? AppColors.forShotType(type.label) : Colors.white70,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                          side: BorderSide(
                            color: selected ? AppColors.forShotType(type.label) : Colors.white24,
                          ),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                const SizedBox(height: 28),

                // Record button
                GestureDetector(
                  onTap: _toggleRecording,
                  child: AnimatedBuilder(
                    animation: _pulseController,
                    builder: (context, child) {
                      final scale = _isRecording ? 1 + (_pulseController.value * 0.08) : 1.0;
                      return Transform.scale(scale: scale, child: child);
                    },
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                      ),
                      padding: const EdgeInsets.all(6),
                      child: Container(
                        decoration: BoxDecoration(
                          shape: _isRecording ? BoxShape.rectangle : BoxShape.circle,
                          borderRadius: _isRecording ? BorderRadius.circular(8) : null,
                          color: AppColors.error,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  _isRecording ? 'Recording…' : 'Tap to record',
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _circleIconButton(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(100),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.45), shape: BoxShape.circle),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}

/// Draws corner brackets + a horizon guideline to help the user frame the
/// shot consistently, which the AI pipeline depends on for accuracy.
class _FramingGuidePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.5)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const margin = 32.0;
    const bracket = 28.0;
    final rect = Rect.fromLTRB(margin, size.height * 0.18, size.width - margin, size.height * 0.82);

    // Top-left
    canvas.drawLine(rect.topLeft, rect.topLeft + const Offset(bracket, 0), paint);
    canvas.drawLine(rect.topLeft, rect.topLeft + const Offset(0, bracket), paint);
    // Top-right
    canvas.drawLine(rect.topRight, rect.topRight + const Offset(-bracket, 0), paint);
    canvas.drawLine(rect.topRight, rect.topRight + const Offset(0, bracket), paint);
    // Bottom-left
    canvas.drawLine(rect.bottomLeft, rect.bottomLeft + const Offset(bracket, 0), paint);
    canvas.drawLine(rect.bottomLeft, rect.bottomLeft + const Offset(0, -bracket), paint);
    // Bottom-right
    canvas.drawLine(rect.bottomRight, rect.bottomRight + const Offset(-bracket, 0), paint);
    canvas.drawLine(rect.bottomRight, rect.bottomRight + const Offset(0, -bracket), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
