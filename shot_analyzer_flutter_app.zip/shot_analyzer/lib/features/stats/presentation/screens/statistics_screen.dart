import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../shared/models/stats_model.dart';
import '../../../../shared/widgets/common_widgets.dart';
import '../widgets/record_and_session_cards.dart';
import '../widgets/stat_cards.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final summary = MockStatsData.summary;
    final records = MockStatsData.personalRecords;
    final sessions = MockStatsData.sessions;
    final progression = MockStatsData.progression;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Statistics'),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => context.pop()),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- Headline stat grid ---
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.5,
                children: [
                  StatHeadlineCard(
                    label: 'Best Score',
                    value: '${summary.bestScore}',
                    icon: Icons.emoji_events_rounded,
                    color: AppColors.accentOrange,
                  ),
                  StatHeadlineCard(
                    label: 'Average Score',
                    value: summary.averageScore.toStringAsFixed(1),
                    icon: Icons.show_chart_rounded,
                    color: AppColors.secondary,
                  ),
                  ImprovementStatCard(
                    label: 'This week vs last',
                    improvementPct: summary.weeklyImprovementPct,
                    periodLabel: 'week',
                  ),
                  ImprovementStatCard(
                    label: 'This month vs last',
                    improvementPct: summary.monthlyImprovementPct,
                    periodLabel: 'month',
                  ),
                ],
              ),

              const SizedBox(height: 28),
              const SectionHeader(title: 'Score Progression (30 days)'),
              AppCard(
                padding: const EdgeInsets.fromLTRB(8, 20, 20, 12),
                child: SizedBox(
                  height: 200,
                  child: _ProgressionLineChart(points: progression),
                ),
              ),

              const SizedBox(height: 24),
              const SectionHeader(title: 'Weekly Comparison'),
              AppCard(
                padding: const EdgeInsets.fromLTRB(8, 20, 20, 12),
                child: SizedBox(
                  height: 160,
                  child: _WeeklyComparisonBarChart(
                    previousAvg: summary.previousWeekAvg,
                    currentAvg: summary.currentWeekAvg,
                  ),
                ),
              ),

              const SizedBox(height: 28),
              const SectionHeader(title: 'Personal Records'),
              ...records.map((r) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: PersonalRecordCard(record: r),
                  )),

              const SizedBox(height: 16),
              const SectionHeader(title: 'Recent Sessions'),
              Text(
                'Shots taken within 2 hours of each other are grouped into a session.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
              ),
              const SizedBox(height: 12),
              ...sessions.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: SessionStatCard(session: s),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProgressionLineChart extends StatelessWidget {
  final List<ProgressionPoint> points;
  const _ProgressionLineChart({required this.points});

  @override
  Widget build(BuildContext context) {
    final spots = <FlSpot>[
      for (int i = 0; i < points.length; i++) FlSpot(i.toDouble(), points[i].avgScore),
    ];

    return LineChart(
      LineChartData(
        minY: 40,
        maxY: 100,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 20,
          getDrawingHorizontalLine: (_) => FlLine(color: AppColors.surfaceBorder, strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 7,
              reservedSize: 24,
              getTitlesWidget: (value, meta) {
                final idx = value.toInt();
                if (idx < 0 || idx >= points.length) return const SizedBox.shrink();
                final date = points[idx].date;
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    '${date.month}/${date.day}',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 10),
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 20,
              reservedSize: 30,
              getTitlesWidget: (value, meta) => Text(
                value.toInt().toString(),
                style: TextStyle(color: AppColors.textMuted, fontSize: 10),
              ),
            ),
          ),
        ),
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            getTooltipColor: (_) => AppColors.surfaceElevated,
            getTooltipItems: (touchedSpots) => touchedSpots.map((spot) {
              return LineTooltipItem(
                spot.y.toStringAsFixed(0),
                const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700),
              );
            }).toList(),
          ),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            curveSmoothness: 0.25,
            color: AppColors.primary,
            barWidth: 2.5,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppColors.primary.withOpacity(0.25), AppColors.primary.withOpacity(0.0)],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WeeklyComparisonBarChart extends StatelessWidget {
  final double? previousAvg;
  final double? currentAvg;
  const _WeeklyComparisonBarChart({required this.previousAvg, required this.currentAvg});

  @override
  Widget build(BuildContext context) {
    final prev = previousAvg ?? 0;
    final curr = currentAvg ?? 0;
    final improved = currentAvg != null && previousAvg != null && curr >= prev;

    return BarChart(
      BarChartData(
        maxY: 100,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 25,
          getDrawingHorizontalLine: (_) => FlLine(color: AppColors.surfaceBorder, strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 25,
              reservedSize: 30,
              getTitlesWidget: (value, meta) => Text(
                value.toInt().toString(),
                style: TextStyle(color: AppColors.textMuted, fontSize: 10),
              ),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (value, meta) {
                final label = value.toInt() == 0 ? 'Last Week' : 'This Week';
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
                );
              },
            ),
          ),
        ),
        barGroups: [
          BarChartGroupData(x: 0, barRods: [
            BarChartRodData(toY: prev, color: AppColors.textMuted, width: 36, borderRadius: BorderRadius.circular(6)),
          ]),
          BarChartGroupData(x: 1, barRods: [
            BarChartRodData(
              toY: curr,
              color: improved ? AppColors.success : AppColors.error,
              width: 36,
              borderRadius: BorderRadius.circular(6),
            ),
          ]),
        ],
      ),
    );
  }
}
