import 'package:flutter/material.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../shared/widgets/common_widgets.dart';

/// A stat card showing a single headline number (Best Score, Average Score).
class StatHeadlineCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const StatHeadlineCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.color = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 10),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
        ],
      ),
    );
  }
}

/// A stat card showing a percentage change with an up/down indicator,
/// colored green for improvement and red/muted for decline. Handles the
/// "not enough data yet" case explicitly rather than showing a misleading 0%.
class ImprovementStatCard extends StatelessWidget {
  final String label;
  final double? improvementPct;
  final String periodLabel;

  const ImprovementStatCard({
    super.key,
    required this.label,
    required this.improvementPct,
    required this.periodLabel,
  });

  @override
  Widget build(BuildContext context) {
    final pct = improvementPct;
    final hasData = pct != null;
    final isPositive = hasData && pct >= 0;
    final color = !hasData ? AppColors.textMuted : (isPositive ? AppColors.success : AppColors.error);
    final icon = !hasData
        ? Icons.remove_rounded
        : (isPositive ? Icons.trending_up_rounded : Icons.trending_down_rounded);

    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 10),
          Text(
            hasData ? '${isPositive ? '+' : ''}${pct.toStringAsFixed(1)}%' : '—',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: hasData ? null : AppColors.textMuted),
          ),
          const SizedBox(height: 2),
          Text(
            hasData ? label : '$label · not enough data',
            style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
