import 'package:flutter/material.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../shared/models/stats_model.dart';
import '../../../../shared/widgets/common_widgets.dart';

class PersonalRecordCard extends StatelessWidget {
  final PersonalRecord record;

  const PersonalRecordCard({super.key, required this.record});

  String _timeAgo(DateTime d) {
    final days = DateTime.now().difference(d).inDays;
    if (days == 0) return 'Today';
    if (days == 1) return 'Yesterday';
    if (days < 30) return '$days days ago';
    return '${(days / 30).floor()} months ago';
  }

  @override
  Widget build(BuildContext context) {
    final color = record.shotType != null ? AppColors.forShotType(record.shotType!.label) : AppColors.primary;
    return AppCard(
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(14)),
            child: Icon(Icons.emoji_events_rounded, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(record.displayLabel, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    if (record.shotType != null) ...[
                      ShotTypeChip(shotType: record.shotType!.label, small: true),
                      const SizedBox(width: 8),
                    ],
                    Text(_timeAgo(record.achievedAt), style: TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
                  ],
                ),
              ],
            ),
          ),
          Text(
            record.value.toStringAsFixed(0),
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: color),
          ),
        ],
      ),
    );
  }
}

class SessionStatCard extends StatelessWidget {
  final SessionStat session;

  const SessionStatCard({super.key, required this.session});

  String _formatDateRange() {
    final start = session.sessionStart;
    final durationMin = session.sessionEnd.difference(session.sessionStart).inMinutes;
    final now = DateTime.now();
    final daysAgo = now.difference(start).inDays;
    final dayLabel = daysAgo == 0 ? 'Today' : (daysAgo == 1 ? 'Yesterday' : '$daysAgo days ago');
    return '$dayLabel · ${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')} · ${durationMin}min';
  }

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: AppColors.darkCardGradient,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.surfaceBorder),
            ),
            child: Center(
              child: Text(
                '${session.shotCount}',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${session.shotCount} shots', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                const SizedBox(height: 2),
                Text(_formatDateRange(), style: TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('Avg ${session.avgScore.toStringAsFixed(0)}', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Text('Best ${session.bestScore}', style: TextStyle(color: AppColors.primary, fontSize: 12.5, fontWeight: FontWeight.w700)),
            ],
          ),
        ],
      ),
    );
  }
}
