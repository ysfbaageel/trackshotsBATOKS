import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/router/app_router.dart';
import '../../../../shared/models/shot_model.dart';
import '../../../../shared/widgets/common_widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final recent = MockData.recent.take(3).toList();

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('Welcome back,', style: TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                    Text('Alex Morgan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  ],
                ),
                CircleAvatar(
                  radius: 22,
                  backgroundColor: AppColors.surfaceElevated,
                  child: const Text('A', style: TextStyle(fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Quick capture card
            AppCard(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Analyze a new shot', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 6),
                        Text(
                          'Record or upload a clip to get instant scoring',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: GradientButton(
                                label: 'Record',
                                icon: Icons.videocam_rounded,
                                onPressed: () => context.push(AppRoutes.record),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () => context.push(AppRoutes.upload),
                            icon: const Icon(Icons.upload_file_rounded, size: 18),
                            label: const Text('Upload from gallery'),
                            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 28),
            const SectionHeader(title: 'This Week'),
            Row(
              children: [
                Expanded(child: _StatTile(label: 'Shots Analyzed', value: '12', icon: Icons.sports_soccer, color: AppColors.primary)),
                const SizedBox(width: 12),
                Expanded(child: _StatTile(label: 'Avg Score', value: '84', icon: Icons.trending_up_rounded, color: AppColors.secondary)),
                const SizedBox(width: 12),
                Expanded(child: _StatTile(label: 'Best Shot', value: '92', icon: Icons.emoji_events_rounded, color: AppColors.accentOrange)),
              ],
            ),

            const SizedBox(height: 8),
            const SectionHeader(title: 'Recent Shots'),
            ...recent.map((shot) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _RecentShotCard(
                    result: shot,
                    onTap: () => context.push(AppRoutes.results, extra: shot),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatTile({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 10),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 11), maxLines: 2),
        ],
      ),
    );
  }
}

class _RecentShotCard extends StatelessWidget {
  final ShotResult result;
  final VoidCallback onTap;

  const _RecentShotCard({required this.result, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: AppColors.forShotType(result.shotType.label).withOpacity(0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(Icons.sports_soccer, color: AppColors.forShotType(result.shotType.label)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShotTypeChip(shotType: result.shotType.label, small: true),
                const SizedBox(height: 6),
                Text(
                  '${result.createdAt.hour}:${result.createdAt.minute.toString().padLeft(2, '0')} · Today',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
              ],
            ),
          ),
          ScoreRing(score: result.overallScore, size: 48, color: AppColors.forShotType(result.shotType.label)),
        ],
      ),
    );
  }
}
