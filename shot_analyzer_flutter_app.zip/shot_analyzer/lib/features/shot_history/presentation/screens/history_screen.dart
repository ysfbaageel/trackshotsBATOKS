import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/router/app_router.dart';
import '../../../../shared/models/shot_model.dart';
import '../../../../shared/widgets/common_widgets.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  ShotType? _filter;

  @override
  Widget build(BuildContext context) {
    final shots = MockData.shotHistory.where((s) => _filter == null || s.shotType == _filter).toList();

    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
            child: Text('History', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                _filterChip(null, 'All'),
                ...ShotType.values.map((t) => _filterChip(t, t.label)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: shots.isEmpty
                ? Center(
                    child: Text('No shots yet for this filter', style: TextStyle(color: AppColors.textMuted)),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                    itemCount: shots.length,
                    itemBuilder: (context, index) {
                      final shot = shots[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _HistoryCard(
                          result: shot,
                          onTap: () => context.push(AppRoutes.results, extra: shot),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _filterChip(ShotType? type, String label) {
    final selected = _filter == type;
    final color = type != null ? AppColors.forShotType(type.label) : AppColors.primary;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _filter = type),
        backgroundColor: AppColors.surfaceElevated,
        selectedColor: color.withOpacity(0.18),
        labelStyle: TextStyle(color: selected ? color : AppColors.textSecondary, fontWeight: FontWeight.w600, fontSize: 13),
        side: BorderSide(color: selected ? color : AppColors.surfaceBorder),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
      ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  final ShotResult result;
  final VoidCallback onTap;

  const _HistoryCard({required this.result, required this.onTap});

  String _formatDate(DateTime d) {
    final now = DateTime.now();
    final diff = now.difference(d);
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  @override
  Widget build(BuildContext context) {
    final color = AppColors.forShotType(result.shotType.label);
    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              gradient: AppColors.darkCardGradient,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.surfaceBorder),
            ),
            child: Icon(Icons.play_circle_fill_rounded, color: color.withOpacity(0.8), size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    ShotTypeChip(shotType: result.shotType.label, small: true),
                    const SizedBox(width: 8),
                    Text(_formatDate(result.createdAt), style: TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  result.feedback,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ScoreRing(score: result.overallScore, size: 46, color: color),
        ],
      ),
    );
  }
}
