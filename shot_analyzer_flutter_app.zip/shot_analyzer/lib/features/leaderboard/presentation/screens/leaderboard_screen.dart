import 'package:flutter/material.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../shared/models/shot_model.dart';
import '../../../../shared/widgets/common_widgets.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  String _period = 'Weekly';
  final _periods = const ['Weekly', 'Monthly', 'All-time'];

  @override
  Widget build(BuildContext context) {
    final entries = mockLeaderboard;
    final top3 = entries.take(3).toList();
    final rest = entries.skip(3).toList();

    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Leaderboard', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(color: AppColors.surfaceElevated, borderRadius: BorderRadius.circular(100)),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _period,
                      dropdownColor: AppColors.surfaceElevated,
                      style: const TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w600),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary, size: 18),
                      items: _periods.map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
                      onChanged: (v) => setState(() => _period = v ?? _period),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Podium
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(child: _PodiumTile(entry: top3[1], height: 96)),
                Expanded(child: _PodiumTile(entry: top3[0], height: 120, isFirst: true)),
                Expanded(child: _PodiumTile(entry: top3[2], height: 76)),
              ],
            ),
          ),

          const SizedBox(height: 24),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
              itemCount: rest.length,
              itemBuilder: (context, index) {
                final entry = rest[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 28,
                          child: Text(
                            entry.rank,
                            style: TextStyle(
                              color: entry.isCurrentUser ? AppColors.primary : AppColors.textMuted,
                              fontWeight: FontWeight.w800,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        CircleAvatar(
                          radius: 18,
                          backgroundColor: entry.isCurrentUser
                              ? AppColors.primary.withOpacity(0.2)
                              : AppColors.surfaceElevated,
                          child: Text(
                            entry.avatarInitial,
                            style: TextStyle(
                              color: entry.isCurrentUser ? AppColors.primary : AppColors.textSecondary,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                entry.name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                  color: entry.isCurrentUser ? AppColors.primary : AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 2),
                              ShotTypeChip(shotType: entry.topShotType.label, small: true),
                            ],
                          ),
                        ),
                        Text('${entry.score}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _PodiumTile extends StatelessWidget {
  final LeaderboardEntry entry;
  final double height;
  final bool isFirst;

  const _PodiumTile({required this.entry, required this.height, this.isFirst = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (isFirst) const Icon(Icons.emoji_events_rounded, color: AppColors.accentYellow, size: 24),
        CircleAvatar(
          radius: isFirst ? 28 : 22,
          backgroundColor: AppColors.surfaceElevated,
          child: Text(entry.avatarInitial, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 6),
        Text(
          entry.name.split(' ').first,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
          overflow: TextOverflow.ellipsis,
        ),
        Text('${entry.score}', style: TextStyle(fontSize: 12, color: AppColors.textMuted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Container(
          height: height,
          margin: const EdgeInsets.symmetric(horizontal: 6),
          decoration: BoxDecoration(
            gradient: isFirst
                ? AppColors.primaryGradient
                : LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [AppColors.surfaceElevated, AppColors.surface],
                  ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
          ),
          alignment: Alignment.topCenter,
          padding: const EdgeInsets.only(top: 10),
          child: Text(
            entry.rank,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 18,
              color: isFirst ? Colors.black : AppColors.textSecondary,
            ),
          ),
        ),
      ],
    );
  }
}
