import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/router/app_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../shared/models/comparison_model.dart';
import '../../../../shared/models/shot_model.dart';
import '../../../../shared/widgets/common_widgets.dart';

class ComparisonPickerScreen extends StatelessWidget {
  final ShotResult yourShot;

  const ComparisonPickerScreen({super.key, required this.yourShot});

  @override
  Widget build(BuildContext context) {
    final references = MockComparisonData.referenceShots;
    final otherShots = MockData.shotHistory.where((s) => s.id != yourShot.id).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Compare Shot'),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => context.pop()),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
          children: [
            AppCard(
              child: Row(
                children: [
                  Icon(Icons.info_outline_rounded, color: AppColors.secondary, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Pro profiles are illustrative references based on well-known shot characteristics — not verified measurements of a specific real shot.',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 11.5, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'Professional References'),
            ...references.map((ref) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ReferenceCard(
                    reference: ref,
                    onTap: () => context.push(
                      AppRoutes.comparisonResult,
                      extra: ComparisonNavArgs(yourShot: yourShot, referenceId: ref.id),
                    ),
                  ),
                )),
            const SizedBox(height: 24),
            const SectionHeader(title: 'Your Other Shots'),
            Text(
              'Compare against a previous shot — including anything you\'ve uploaded from your gallery.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
            ),
            const SizedBox(height: 12),
            if (otherShots.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Text('No other analyzed shots yet.', style: TextStyle(color: AppColors.textMuted)),
              )
            else
              ...otherShots.map((shot) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _OwnShotCard(
                      shot: shot,
                      onTap: () => context.push(
                        AppRoutes.comparisonResult,
                        extra: ComparisonNavArgs(yourShot: yourShot, compareToShot: shot),
                      ),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}

class _ReferenceCard extends StatelessWidget {
  final ReferenceShot reference;
  final VoidCallback onTap;

  const _ReferenceCard({required this.reference, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = AppColors.forShotType(reference.shotType.label);
    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(14)),
            child: Icon(Icons.sports_soccer, color: color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(reference.playerStyle, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                const SizedBox(height: 4),
                ShotTypeChip(shotType: reference.shotType.label, small: true),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
        ],
      ),
    );
  }
}

class _OwnShotCard extends StatelessWidget {
  final ShotResult shot;
  final VoidCallback onTap;

  const _OwnShotCard({required this.shot, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = AppColors.forShotType(shot.shotType.label);
    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: AppColors.darkCardGradient,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.surfaceBorder),
            ),
            child: Icon(Icons.play_circle_fill_rounded, color: color.withOpacity(0.8), size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShotTypeChip(shotType: shot.shotType.label, small: true),
                const SizedBox(height: 4),
                Text('Score ${shot.overallScore}', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
        ],
      ),
    );
  }
}

/// Navigation payload for the comparison result route — carries either a
/// reference id or another shot to compare against.
class ComparisonNavArgs {
  final ShotResult yourShot;
  final String? referenceId;
  final ShotResult? compareToShot;

  const ComparisonNavArgs({required this.yourShot, this.referenceId, this.compareToShot});
}
