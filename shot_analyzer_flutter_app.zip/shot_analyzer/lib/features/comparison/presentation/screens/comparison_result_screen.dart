import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../shared/models/comparison_model.dart';
import '../../../../shared/widgets/common_widgets.dart';
import 'comparison_picker_screen.dart';

class ComparisonResultScreen extends StatelessWidget {
  final ComparisonNavArgs args;

  const ComparisonResultScreen({super.key, required this.args});

  @override
  Widget build(BuildContext context) {
    final result = args.referenceId != null
        ? MockComparisonData.compare(yourShotType: args.yourShot.shotType, referenceId: args.referenceId!)
        : MockComparisonData.compareShots(args.yourShot, args.compareToShot!);

    final yourColor = AppColors.primary;
    final targetColor = AppColors.forShotType(result.target.shotType.label);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Shot Comparison'),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new, size: 18), onPressed: () => context.pop()),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (result.target.isIllustrative)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: AppCard(
                    child: Row(
                      children: [
                        Icon(Icons.info_outline_rounded, color: AppColors.warning, size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Illustrative reference profile — not verified measurement data for a specific real shot.',
                            style: TextStyle(color: AppColors.textSecondary, fontSize: 11.5, height: 1.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // --- Overall similarity ---
              Center(
                child: Column(
                  children: [
                    ScoreRing(
                      score: result.overallSimilarityPct.round(),
                      size: 130,
                      color: _similarityColor(result.overallSimilarityPct),
                      label: 'SIMILARITY',
                    ),
                    const SizedBox(height: 14),
                    Text(
                      result.summary,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // --- Side labels ---
              Row(
                children: [
                  Expanded(child: _SideLabel(label: result.yourShot.label, color: yourColor)),
                  const SizedBox(width: 12),
                  Expanded(child: _SideLabel(label: result.target.label, color: targetColor)),
                ],
              ),

              const SizedBox(height: 16),
              const SectionHeader(title: 'Trajectory'),
              AppCard(
                padding: const EdgeInsets.fromLTRB(8, 20, 20, 12),
                child: SizedBox(
                  height: 200,
                  child: _OverlaidTrajectoryChart(
                    yourShot: result.yourShot,
                    target: result.target,
                    yourColor: yourColor,
                    targetColor: targetColor,
                  ),
                ),
              ),

              const SizedBox(height: 24),
              const SectionHeader(title: 'Dimension Breakdown'),
              ...result.dimensions.map((d) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _DimensionRow(
                      dimension: d,
                      yourColor: yourColor,
                      targetColor: targetColor,
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Color _similarityColor(double pct) {
    if (pct >= 80) return AppColors.success;
    if (pct >= 55) return AppColors.secondary;
    if (pct >= 35) return AppColors.warning;
    return AppColors.error;
  }
}

class _SideLabel extends StatelessWidget {
  final String label;
  final Color color;

  const _SideLabel({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}

class _OverlaidTrajectoryChart extends StatelessWidget {
  final ComparisonSide yourShot;
  final ComparisonSide target;
  final Color yourColor;
  final Color targetColor;

  const _OverlaidTrajectoryChart({
    required this.yourShot,
    required this.target,
    required this.yourColor,
    required this.targetColor,
  });

  List<FlSpot> _toSpots(ComparisonSide side) {
    final duration = side.trajectory.last.timestampSec;
    if (duration <= 0) return [const FlSpot(0, 0)];
    return side.trajectory
        .map((p) => FlSpot(p.timestampSec / duration, p.heightM))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final yourSpots = _toSpots(yourShot);
    final targetSpots = _toSpots(target);
    final maxHeight = [
      ...yourSpots.map((s) => s.y),
      ...targetSpots.map((s) => s.y),
    ].reduce((a, b) => a > b ? a : b);

    return LineChart(
      LineChartData(
        minX: 0,
        maxX: 1,
        minY: 0,
        maxY: maxHeight * 1.15,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => FlLine(color: AppColors.surfaceBorder, strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 0.25,
              reservedSize: 24,
              getTitlesWidget: (value, meta) => Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('${(value * 100).round()}%', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
              ),
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 32,
              getTitlesWidget: (value, meta) => Text(
                '${value.toStringAsFixed(1)}m',
                style: TextStyle(color: AppColors.textMuted, fontSize: 10),
              ),
            ),
          ),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: yourSpots,
            isCurved: true,
            color: yourColor,
            barWidth: 2.5,
            dotData: const FlDotData(show: false),
          ),
          LineChartBarData(
            spots: targetSpots,
            isCurved: true,
            color: targetColor,
            barWidth: 2.5,
            dashArray: [6, 4],
            dotData: const FlDotData(show: false),
          ),
        ],
      ),
    );
  }
}

class _DimensionRow extends StatelessWidget {
  final DimensionComparison dimension;
  final Color yourColor;
  final Color targetColor;

  const _DimensionRow({required this.dimension, required this.yourColor, required this.targetColor});

  String _formatValue(double v) {
    if (dimension.unit == 'shape' || dimension.unit == 'score') return v.toStringAsFixed(0);
    return v.toStringAsFixed(1);
  }

  @override
  Widget build(BuildContext context) {
    final simColor = dimension.similarityPct >= 80
        ? AppColors.success
        : dimension.similarityPct >= 55
            ? AppColors.secondary
            : dimension.similarityPct >= 35
                ? AppColors.warning
                : AppColors.error;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(dimension.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              Text('${dimension.similarityPct.toStringAsFixed(0)}% match',
                  style: TextStyle(color: simColor, fontWeight: FontWeight.w700, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 10),
          if (dimension.unit != 'shape')
            Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Container(width: 8, height: 8, decoration: BoxDecoration(color: yourColor, shape: BoxShape.circle)),
                      const SizedBox(width: 6),
                      Text('${_formatValue(dimension.yourValue)} ${dimension.unit}',
                          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('${_formatValue(dimension.targetValue)} ${dimension.unit}',
                          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                      const SizedBox(width: 6),
                      Container(width: 8, height: 8, decoration: BoxDecoration(color: targetColor, shape: BoxShape.circle)),
                    ],
                  ),
                ),
              ],
            ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: dimension.similarityPct / 100,
              minHeight: 6,
              backgroundColor: AppColors.surfaceElevated,
              valueColor: AlwaysStoppedAnimation(simColor),
            ),
          ),
        ],
      ),
    );
  }
}
