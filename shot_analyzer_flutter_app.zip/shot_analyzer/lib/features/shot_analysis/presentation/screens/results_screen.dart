import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/router/app_router.dart';
import '../../../../shared/models/shot_model.dart';
import '../../../../shared/widgets/common_widgets.dart';

class ResultsScreen extends StatelessWidget {
  final ShotResult result;
  const ResultsScreen({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    final color = AppColors.forShotType(result.shotType.label);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Shot Result'),
        leading: IconButton(
          icon: const Icon(Icons.close_rounded),
          onPressed: () => context.go(AppRoutes.home),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.ios_share_rounded), onPressed: () {}),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PitchPlaceholder(
                height: 200,
                overlay: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), shape: BoxShape.circle),
                  child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 32),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Column(
                  children: [
                    ScoreRing(score: result.overallScore, size: 140, color: color, label: 'OVERALL'),
                    const SizedBox(height: 14),
                    ShotTypeChip(shotType: result.shotType.label),
                    const SizedBox(height: 10),
                    if (result.confidence < 0.75)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.warning.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(100),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.warning),
                            const SizedBox(width: 6),
                            Text(
                              'Preliminary rating · model still learning this shot type',
                              style: TextStyle(color: AppColors.warning, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const SectionHeader(title: 'Breakdown'),
              AppCard(
                child: Column(
                  children: result.metrics
                      .map((m) => MetricBar(label: m.label, value: m.value, rawDisplay: m.rawDisplay, color: color))
                      .toList(),
                ),
              ),
              const SizedBox(height: 24),
              const SectionHeader(title: 'Coach Feedback'),
              AppCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(10)),
                      child: Icon(Icons.tips_and_updates_rounded, color: color, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        result.feedback,
                        style: const TextStyle(fontSize: 13.5, height: 1.5, color: AppColors.textSecondary),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => context.push(AppRoutes.comparisonPicker, extra: result),
                  icon: const Icon(Icons.compare_arrows_rounded, size: 18, color: AppColors.secondary),
                  label: const Text('Compare to Pro or Another Shot', style: TextStyle(color: AppColors.secondary)),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.secondary)),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => context.go(AppRoutes.home),
                      icon: const Icon(Icons.home_rounded, size: 18),
                      label: const Text('Home'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: GradientButton(
                      label: 'Analyze Another',
                      icon: Icons.videocam_rounded,
                      onPressed: () => context.push(AppRoutes.record),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
