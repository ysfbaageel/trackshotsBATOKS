import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/router/app_router.dart';
import '../../../../shared/models/shot_model.dart';

/// Shown while the backend job runs. In production this subscribes to
/// `WS /v1/ws/jobs/{job_id}` (falling back to polling `GET /shots/{id}/status`)
/// and maps `analysis_jobs.stage` to the step list below.
class ProcessingScreen extends StatefulWidget {
  final ShotType shotType;
  const ProcessingScreen({super.key, required this.shotType});

  @override
  State<ProcessingScreen> createState() => _ProcessingScreenState();
}

class _ProcessingScreenState extends State<ProcessingScreen> with SingleTickerProviderStateMixin {
  final List<String> _stages = const [
    'Uploading video',
    'Detecting ball & player pose',
    'Tracking trajectory',
    'Extracting shot features',
    'Scoring performance',
  ];
  int _currentStage = 0;
  late final AnimationController _rotationController;

  @override
  void initState() {
    super.initState();
    _rotationController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
    _advance();
  }

  void _advance() async {
    for (int i = 0; i < _stages.length; i++) {
      await Future.delayed(const Duration(milliseconds: 1100));
      if (!mounted) return;
      setState(() => _currentStage = i);
    }
    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    context.go(AppRoutes.results, extra: MockData.shotHistory.first);
  }

  @override
  void dispose() {
    _rotationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = AppColors.forShotType(widget.shotType.label);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 140,
                height: 140,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    RotationTransition(
                      turns: _rotationController,
                      child: SizedBox(
                        width: 140,
                        height: 140,
                        child: CircularProgressIndicator(
                          value: null,
                          strokeWidth: 4,
                          valueColor: AlwaysStoppedAnimation(color.withOpacity(0.85)),
                          backgroundColor: AppColors.surfaceElevated,
                        ),
                      ),
                    ),
                    Icon(Icons.sports_soccer, color: color, size: 48),
                  ],
                ),
              ),
              const SizedBox(height: 36),
              Text(
                'Analyzing your ${widget.shotType.label} shot',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              Text(
                'This usually takes 10–20 seconds',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
              ),
              const SizedBox(height: 40),
              ...List.generate(_stages.length, (index) {
                final done = index < _currentStage;
                final active = index == _currentStage;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: done || active ? color.withOpacity(done ? 1 : 0.18) : AppColors.surfaceElevated,
                          border: Border.all(color: done || active ? color : AppColors.surfaceBorder, width: 1.5),
                        ),
                        child: done
                            ? const Icon(Icons.check, size: 14, color: Colors.black)
                            : active
                                ? Padding(
                                    padding: const EdgeInsets.all(6),
                                    child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation(color)),
                                  )
                                : null,
                      ),
                      const SizedBox(width: 14),
                      Text(
                        _stages[index],
                        style: TextStyle(
                          color: done || active ? AppColors.textPrimary : AppColors.textMuted,
                          fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
