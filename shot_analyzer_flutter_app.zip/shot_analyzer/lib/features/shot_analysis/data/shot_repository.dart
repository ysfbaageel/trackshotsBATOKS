import 'dart:io';
import 'package:dio/dio.dart';
import '../../../../core/network/api_client.dart';

/// Mirrors app/schemas/shot.py::ShotResultResponse from the backend
/// exactly — every field the full AI -> physics -> rating -> coaching
/// pipeline produces.
class RemoteShotResult {
  final String id;
  final String shotId;
  final String detectedShotType;
  final int overallScore;
  final Map<String, double> categoryScores;
  final double ballSpeedKmh;
  final double launchAngleDeg;
  final double horizontalCurveM;
  final double peakHeightM;
  final double spinRateRps;
  final List<RemoteShotMetric> metrics;
  final List<RemoteTrajectoryPoint> trajectoryPoints;
  final String feedbackText;
  final List<RemoteCoachingTip> coachingTips;
  final double confidence;
  final String? overlayVideoUrl;
  final String modelVersion;

  RemoteShotResult({
    required this.id,
    required this.shotId,
    required this.detectedShotType,
    required this.overallScore,
    required this.categoryScores,
    required this.ballSpeedKmh,
    required this.launchAngleDeg,
    required this.horizontalCurveM,
    required this.peakHeightM,
    required this.spinRateRps,
    required this.metrics,
    required this.trajectoryPoints,
    required this.feedbackText,
    required this.coachingTips,
    required this.confidence,
    this.overlayVideoUrl,
    required this.modelVersion,
  });

  factory RemoteShotResult.fromJson(Map<String, dynamic> json) => RemoteShotResult(
        id: json['id'] as String,
        shotId: json['shot_id'] as String,
        detectedShotType: json['detected_shot_type'] as String,
        overallScore: json['overall_score'] as int,
        categoryScores: (json['category_scores'] as Map<String, dynamic>)
            .map((k, v) => MapEntry(k, (v as num).toDouble())),
        ballSpeedKmh: (json['ball_speed_kmh'] as num).toDouble(),
        launchAngleDeg: (json['launch_angle_deg'] as num).toDouble(),
        horizontalCurveM: (json['horizontal_curve_m'] as num).toDouble(),
        peakHeightM: (json['peak_height_m'] as num).toDouble(),
        spinRateRps: (json['spin_rate_rps'] as num).toDouble(),
        metrics: (json['metrics'] as List).map((m) => RemoteShotMetric.fromJson(m)).toList(),
        trajectoryPoints:
            (json['trajectory_points'] as List).map((p) => RemoteTrajectoryPoint.fromJson(p)).toList(),
        feedbackText: json['feedback_text'] as String,
        coachingTips: (json['coaching_tips'] as List).map((t) => RemoteCoachingTip.fromJson(t)).toList(),
        confidence: (json['confidence'] as num).toDouble(),
        overlayVideoUrl: json['overlay_video_url'] as String?,
        modelVersion: json['model_version'] as String,
      );
}

class RemoteShotMetric {
  final String label;
  final double value;
  final String rawDisplay;
  final String? unit;

  RemoteShotMetric({required this.label, required this.value, required this.rawDisplay, this.unit});

  factory RemoteShotMetric.fromJson(Map<String, dynamic> json) => RemoteShotMetric(
        label: json['label'] as String,
        value: (json['value'] as num).toDouble(),
        rawDisplay: json['raw_display'] as String,
        unit: json['unit'] as String?,
      );
}

class RemoteTrajectoryPoint {
  final double timestampSec;
  final double xM;
  final double heightM;

  RemoteTrajectoryPoint({required this.timestampSec, required this.xM, required this.heightM});

  factory RemoteTrajectoryPoint.fromJson(Map<String, dynamic> json) => RemoteTrajectoryPoint(
        timestampSec: (json['timestamp_sec'] as num).toDouble(),
        xM: (json['x_m'] as num).toDouble(),
        heightM: (json['height_m'] as num).toDouble(),
      );
}

class RemoteCoachingTip {
  final String id;
  final String headline;
  final String explanation;
  final String category;
  final String basis;
  final double severity;

  RemoteCoachingTip({
    required this.id,
    required this.headline,
    required this.explanation,
    required this.category,
    required this.basis,
    required this.severity,
  });

  factory RemoteCoachingTip.fromJson(Map<String, dynamic> json) => RemoteCoachingTip(
        id: json['id'] as String,
        headline: json['headline'] as String,
        explanation: json['explanation'] as String,
        category: json['category'] as String,
        basis: json['basis'] as String,
        severity: (json['severity'] as num).toDouble(),
      );
}

class ShotStatus {
  final String shotId;
  final String status; // uploaded | queued | processing | completed | failed
  final String? stage;
  final int progressPercent;
  final String? errorMessage;

  ShotStatus({
    required this.shotId,
    required this.status,
    this.stage,
    required this.progressPercent,
    this.errorMessage,
  });

  factory ShotStatus.fromJson(Map<String, dynamic> json) => ShotStatus(
        shotId: json['shot_id'] as String,
        status: json['status'] as String,
        stage: json['stage'] as String?,
        progressPercent: json['progress_percent'] as int,
        errorMessage: json['error_message'] as String?,
      );
}

/// Real shot upload -> analysis -> result flow, matching the backend's
/// video processing design exactly: the video is uploaded DIRECTLY to
/// object storage via a presigned URL (never proxied through the API
/// server), then the API is told about it separately.
class ShotRepository {
  final ApiClient _apiClient;
  final Dio _uploadDio = Dio(); // separate, header-free client for the presigned S3 PUT

  ShotRepository(this._apiClient);

  /// Step 1: get a presigned upload URL. Step 2: PUT the file bytes
  /// directly to that URL. Step 3: tell the API the shot exists (which
  /// enqueues the analysis job). Returns the created shot's id.
  Future<String> uploadAndSubmit({
    required File videoFile,
    required String shotType,
    required String idempotencyKey,
    Map<String, dynamic>? deviceMetadata,
  }) async {
    final extension = videoFile.path.split('.').last.toLowerCase();
    final contentType = extension == 'mov' ? 'video/quicktime' : 'video/mp4';

    final uploadUrlResponse = await _apiClient.post('/shots/upload-url', data: {
      'file_extension': extension,
      'content_type': contentType,
    });
    final uploadUrl = uploadUrlResponse['upload_url'] as String;
    final storageKey = uploadUrlResponse['storage_key'] as String;

    await _uploadDio.put(
      uploadUrl,
      data: videoFile.openRead(),
      options: Options(
        headers: {
          'Content-Type': contentType,
          Headers.contentLengthHeader: await videoFile.length(),
        },
      ),
    );

    final shotResponse = await _apiClient.post('/shots', data: {
      'storage_key': storageKey,
      'shot_type': shotType,
      'idempotency_key': idempotencyKey,
      if (deviceMetadata != null) 'device_metadata': deviceMetadata,
    });

    return shotResponse['id'] as String;
  }

  Future<ShotStatus> getStatus(String shotId) async {
    final json = await _apiClient.get('/shots/$shotId/status');
    return ShotStatus.fromJson(json);
  }

  Future<RemoteShotResult> getResult(String shotId) async {
    final json = await _apiClient.get('/shots/$shotId/result');
    return RemoteShotResult.fromJson(json);
  }

  /// Polls status until the job reaches a terminal state, yielding each
  /// update — used as a fallback when the WebSocket channel (see
  /// `job_status_websocket.dart`) isn't connected. Stops after
  /// [maxAttempts] to avoid polling forever if something goes wrong.
  Stream<ShotStatus> pollStatus(String shotId, {int maxAttempts = 60, Duration interval = const Duration(seconds: 2)}) async* {
    for (int i = 0; i < maxAttempts; i++) {
      final status = await getStatus(shotId);
      yield status;
      if (status.status == 'completed' || status.status == 'failed') return;
      await Future.delayed(interval);
    }
  }
}
