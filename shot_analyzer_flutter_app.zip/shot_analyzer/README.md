# Shot Analyzer — Flutter Frontend

Complete UI-only build of the football shot analysis app. All 13 screens are implemented with mock data so the full flow can be reviewed and demoed before backend integration.

## Screens included

| Screen | Path |
|---|---|
| Splash | `lib/features/splash/presentation/screens/splash_screen.dart` |
| Login | `lib/features/auth/presentation/screens/login_screen.dart` |
| Register | `lib/features/auth/presentation/screens/register_screen.dart` |
| Home (+ bottom nav shell) | `lib/features/home/presentation/screens/home_screen.dart`, `home_shell_screen.dart` |
| Record Video | `lib/features/shot_capture/presentation/screens/record_video_screen.dart` |
| Upload Video | `lib/features/shot_capture/presentation/screens/upload_video_screen.dart` |
| Video Preview | `lib/features/shot_capture/presentation/screens/video_preview_screen.dart` |
| Processing | `lib/features/shot_analysis/presentation/screens/processing_screen.dart` |
| Results | `lib/features/shot_analysis/presentation/screens/results_screen.dart` |
| History | `lib/features/shot_history/presentation/screens/history_screen.dart` |
| Leaderboard | `lib/features/leaderboard/presentation/screens/leaderboard_screen.dart` |
| Profile | `lib/features/profile/presentation/screens/profile_screen.dart` |
| Settings | `lib/features/settings/presentation/screens/settings_screen.dart` |

## Run it

```bash
flutter pub get
flutter run
```

Requires Flutter 3.22+ (Dart 3.3+). No backend or Firebase project is wired up yet — every action (login, record, upload, processing) uses mock delays and static data from `lib/shared/models/shot_model.dart` so the UI can be reviewed standalone.

## What's real vs. mocked

**Real:** navigation flow (go_router), theming, all layouts/animations, form validation, state management within each screen.

**Mocked / stubbed for next phase:**
- `record_video_screen.dart` — camera preview is a styled placeholder; swap in a `CameraController` from the `camera` package and wire `startVideoRecording()`/`stopVideoRecording()` where `_toggleRecording()` currently simulates a countdown.
- `upload_video_screen.dart` — file picker isn't wired; add `image_picker` or `file_picker` for the gallery grid and tap targets.
- `video_preview_screen.dart` — swap `PitchPlaceholder` for a real `VideoPlayerController` (the `video_player` package is already in `pubspec.yaml`).
- `processing_screen.dart` — stage progression is a timed simulation; replace with a WebSocket subscription (`WS /v1/ws/jobs/{job_id}`) per the backend architecture, falling back to polling `GET /shots/{id}/status`.
- Auth screens call `Future.delayed` instead of Firebase Auth SDK calls.
- All data (`shot_model.dart`'s `MockData`) should be replaced by repository calls once the API client (Dio + Retrofit-style services) is added under `lib/features/*/data/`.

## Backend integration layer

A real, working API client and repository layer now exists alongside the mock data — matching the FastAPI backend's contracts exactly:

- **`lib/core/network/api_client.dart`** — Dio-based HTTP client. Attaches the current Firebase ID token to every request, maps every failure onto a typed `ApiException` matching the backend's `{error_code, message}` error envelope.
- **`lib/features/auth/data/auth_repository.dart`** — real Firebase Auth calls (sign in, register, sign out, password reset) followed by `POST /auth/sync` to create/fetch the backend's local profile row, exactly matching the backend's "Firebase issues identity, backend syncs on first sight" design.
- **`lib/features/shot_analysis/data/shot_repository.dart`** — the real upload flow: request a presigned URL, `PUT` the video directly to object storage (never proxied through the API), tell the API the shot exists, poll or fetch results — with response models matching `app/schemas/shot.py::ShotResultResponse` field-for-field, including the full physics/rating/coaching breakdown.

**Toggle**: `lib/core/config/app_config.dart`'s `AppConfig.useMockData` (default `true`) controls whether the app uses the existing mock data (as built and demoed throughout this project) or these real repositories. Flip it once pointed at a running backend.

**What's honestly not done**: no screen has actually been rewired to call these repositories instead of `MockData` yet — that's a mechanical, well-defined task per screen (swap the `Future.delayed`/`MockData.x` call for the matching repository method) now that the repositories themselves are correct and complete. Firebase Auth also requires a real Firebase project (`flutterfire configure` generates `firebase_options.dart`, which needs actual project credentials that don't exist for a project that was never created) — the auth code is correct, standard Firebase Auth usage, but has not been exercised against a live project.

## Design system

Dark, high-contrast "night match" theme — see `lib/app/theme/app_theme.dart` for the full palette and `lib/shared/widgets/common_widgets.dart` for reusable components (`GradientButton`, `ScoreRing`, `ShotTypeChip`, `MetricBar`, `AppCard`, `PitchPlaceholder`). Each shot type has a consistent accent color (`AppColors.forShotType()`) used across chips, charts, and score rings so it's instantly recognizable throughout the app.

## Folder structure

Follows the feature-first Clean Architecture layout from the original system design: each feature has `data/` (not yet populated — mocked for now), `domain/` (not yet populated), and `presentation/` (screens + widgets), ready to fill in without restructuring when the API layer is added.
